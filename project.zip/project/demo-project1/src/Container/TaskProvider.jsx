import React, { useEffect, useState } from "react";

const API_URL = "https://crud-backend.onrender.com/api/items"; // Change this to your backend URL

export default function App() {
  const [items, setItems] = useState([]);
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then(setItems)
      .catch(console.error);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingId) {
      fetch(`${API_URL}/${editingId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      })
        .then((res) => res.json())
        .then((updated) => {
          setItems(items.map((i) => (i.id === editingId ? updated : i)));
          setName("");
          setEditingId(null);
        });
    } else {
      fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      })
        .then((res) => res.json())
        .then((newItem) => {
          setItems([...items, newItem]);
          setName("");
        });
    }
  };

  const handleDelete = (id) => {
    fetch(`${API_URL}/${id}`, { method: "DELETE" }).then(() => {
      setItems(items.filter((i) => i.id !== id));
    });
  };

  const handleEdit = (item) => {
    setEditingId(item.id);
    setName(item.name);
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", padding: 20 }}>
      <h1>CRUD App</h1>
      <form onSubmit={handleSubmit}>
        <input
          value={name}
          placeholder="Item name"
          onChange={(e) => setName(e.target.value)}
          style={{ padding: 8, width: "70%" }}
        />
        <button type="submit" style={{ marginLeft: 8 }}>
          {editingId ? "Update" : "Add"}
        </button>
        {editingId && (
          <button
            type="button"
            onClick={() => {
              setName("");
              setEditingId(null);
            }}
            style={{ marginLeft: 8 }}
          >
            Cancel
          </button>
        )}
      </form>

      <ul style={{ padding: 0, listStyle: "none", marginTop: 20 }}>
        {items.map((item) => (
          <li key={item.id} style={{ marginBottom: 10 }}>
            {item.name}
            <button
              onClick={() => handleEdit(item)}
              style={{ marginLeft: 10 }}
            >
              Edit
            </button>
            <button
              onClick={() => handleDelete(item.id)}
              style={{ marginLeft: 10, color: "red" }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}